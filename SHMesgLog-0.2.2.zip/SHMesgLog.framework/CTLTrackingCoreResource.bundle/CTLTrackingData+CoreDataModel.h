//
//  CTLTrackingData+CoreDataModel.h
//  
//
//  Created by Le Minh Son on 2/19/19.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "Tracking+CoreDataClass.h"




