//
//  Tracking+CoreDataClass.h
//  
//
//  Created by Le Minh Son on 2/19/19.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Tracking : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Tracking+CoreDataProperties.h"
